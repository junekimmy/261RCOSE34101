#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>

#define SLEEP_TIME 2

int main(int argc, char* argv[]) {
    pid_t pid;
    int status;
    int parent_pid, child_pid, favorite_number;
    char favorite_fruit[] = "Apple";

    printf("Final Question!\n");

    pid = fork();

    switch (pid) {
    case -1:
        printf("fork failed\n");
        return -1;

    default:
        parent_pid = getpid();

        printf("[%d] I am a parent\n", parent_pid);

        wait(&status);

        printf("[%d] ....and my child's favorite number is %d\n",
               parent_pid, WEXITSTATUS(status));
        break;

    case 0:
        sleep(SLEEP_TIME);

        favorite_number = 5;
        child_pid = getpid();
        parent_pid = getppid();

        printf("[%d] and I am a child! And my parent's PID is [%d]\n",
               child_pid, parent_pid);

        printf("[%d] my parent's favorite fruit is %s but he doesn't know that my favorite number is %d\n",
               child_pid, favorite_fruit, favorite_number);

        exit(favorite_number);
    }

    return 0;
}