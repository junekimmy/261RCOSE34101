#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[]){
    printf("where am I?\n");

    execl("/bin/pwd", "pwd", NULL);

    return 0;
}