#include <stdio.h>
#include <stdatomic.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/wait.h>
#include <stdint.h>
#define NUM_TASKS 3
#define SPREADING 2

static _Atomic int cnt_task = NUM_TASKS;

pthread_mutex_t lock;
pthread_cond_t cond;

void spread_words() {
    sleep(SPREADING);
    printf("[subordinate] spreading words...\n");
    
    pthread_mutex_lock(&lock);
    cnt_task--;
    if (cnt_task == 0) {
        pthread_cond_signal(&cond);
    }
    pthread_mutex_unlock(&lock);
}

void* subordinate(void* arg) {
    sleep(SPREADING);
    printf("[subordinate] as you wish\n");
    for(int i = 0; i < 3; i++) {
        spread_words();
    }
    pthread_exit(NULL);
}

void* king(void* arg) {
    pthread_t tid;
    int status;
    printf("spread the words ");

    status = pthread_create(&tid, NULL, subordinate, NULL);
    if (status != 0) {
        printf("error");
        pthread_exit(NULL);
    }

    pthread_detach(tid);

    printf("that I am king!\n");
    pthread_exit(NULL);
}

int main(int argc, char* argv[]) {
    pthread_t tid;
    int status;

    pthread_mutex_init(&lock, NULL);
    pthread_cond_init(&cond, NULL);

    status = pthread_create(&tid, NULL, king, NULL);
    if (status != 0) {
        printf("error");
        return -1;
    }
    pthread_join(tid, NULL);

    pthread_mutex_lock(&lock);
    while (cnt_task > 0) {
        pthread_cond_wait(&cond, &lock);
    }
    pthread_mutex_unlock(&lock);

    pthread_mutex_destroy(&lock);
    pthread_cond_destroy(&cond);

    printf("The words have been spread...\n");
    return 0;
}